<section class="form-card narrow" aria-labelledby="register-title">
  <p class="eyebrow">Student account request</p>
  <h1 id="register-title">Request a student account</h1>
  <p>Browse food without signing in. New student accounts require administrator approval before they can order, manage a cart, or review food.</p>
  <form method="post" action="<?= h(app_url('auth.register')) ?>" class="stack" data-submit-feedback>
    <?= csrf_field() ?>
    <div class="form-field"><label for="full-name">Full name</label><input id="full-name" name="full_name" autocomplete="name" maxlength="120" value="<?= h(old('full_name')) ?>"<?= form_field_invalid_attr('full_name') ?> required><?= field_error_html('full_name') ?></div>
    <div class="form-field"><label for="email">Email</label><input id="email" type="email" name="email" autocomplete="email" maxlength="190" value="<?= h(old('email')) ?>"<?= form_field_invalid_attr('email') ?> required><?= field_error_html('email') ?></div>
    <div class="form-field"><label for="phone">Phone <span class="muted">(optional)</span></label><input id="phone" type="tel" name="phone" autocomplete="tel" maxlength="30" value="<?= h(old('phone')) ?>"<?= form_field_invalid_attr('phone') ?>><?= field_error_html('phone') ?></div>
    <div class="form-field"><label for="password">Password</label><input id="password" type="password" name="password" autocomplete="new-password" minlength="10" maxlength="72"<?= form_field_invalid_attr('password') ?> required><span class="field-hint">Use 10 or more characters, up to 72 bytes.</span><?= field_error_html('password') ?></div>
    <div class="form-field"><label for="password-confirm">Confirm password</label><input id="password-confirm" type="password" name="password_confirmation" autocomplete="new-password" minlength="10" maxlength="72"<?= form_field_invalid_attr('password_confirmation') ?> required><?= field_error_html('password_confirmation') ?></div>
    <button class="button" type="submit" data-loading-text="Submitting…">Submit account request</button>
  </form>
  <p class="small muted" style="margin:18px 0 0">Already have an account? <a href="<?= h(app_url('auth.login')) ?>">Sign in</a>.</p>
</section>
